import React from 'react';
import { BarChart2, Users, Plane, Settings } from 'lucide-react';

interface DashboardProps {
  issues: string[];
  feedbackData: any[];
}

const Dashboard: React.FC<DashboardProps> = ({ issues, feedbackData }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <DashboardCard
        icon={<BarChart2 className="text-blue-500" size={24} />}
        title="Production Efficiency"
        value={`${feedbackData.find(d => d.category === 'Production')?.value || 0}%`}
      />
      <DashboardCard
        icon={<Users className="text-green-500" size={24} />}
        title="Customer Satisfaction"
        value={`${feedbackData.find(d => d.category === 'Customer')?.value || 0}%`}
      />
      <DashboardCard
        icon={<Plane className="text-purple-500" size={24} />}
        title="Service Performance"
        value={`${feedbackData.find(d => d.category === 'Service')?.value || 0}%`}
      />
      <DashboardCard
        icon={<Settings className="text-red-500" size={24} />}
        title="Open Issues"
        value={issues.length.toString()}
      />
    </div>
  );
};

interface DashboardCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ icon, title, value }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <div className="flex items-center justify-between mb-4">
      {icon}
      <h3 className="text-lg font-semibold text-gray-700">{title}</h3>
    </div>
    <p className="text-3xl font-bold text-gray-900">{value}</p>
  </div>
);

export default Dashboard;