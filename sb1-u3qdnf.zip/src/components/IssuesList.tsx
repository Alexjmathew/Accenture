import React from 'react';
import { AlertCircle } from 'lucide-react';

interface IssuesListProps {
  issues: string[];
}

const IssuesList: React.FC<IssuesListProps> = ({ issues }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Current Issues</h2>
      {issues.length === 0 ? (
        <p className="text-gray-600">No issues reported.</p>
      ) : (
        <ul className="space-y-4">
          {issues.map((issue, index) => (
            <li key={index} className="flex items-start space-x-3 p-3 bg-red-50 rounded-md">
              <AlertCircle className="text-red-500 flex-shrink-0" />
              <span className="text-gray-800">{issue}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default IssuesList;