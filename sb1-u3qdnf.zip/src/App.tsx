import React, { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, BarChart2, Users, Plane, Settings } from 'lucide-react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import FeedbackForm from './components/FeedbackForm';
import AnalyticsChart from './components/AnalyticsChart';
import IssuesList from './components/IssuesList';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [issues, setIssues] = useState<string[]>([]);
  const [feedbackData, setFeedbackData] = useState<any[]>([]);

  useEffect(() => {
    // Simulating fetching initial data
    setIssues(['Engine efficiency below target', 'Cabin pressure fluctuations', 'Landing gear sensor malfunction']);
    setFeedbackData([
      { category: 'Production', value: 75 },
      { category: 'Customer', value: 82 },
      { category: 'Service', value: 90 },
    ]);
  }, []);

  const handleNewFeedback = (feedback: string) => {
    setIssues((prevIssues) => [...prevIssues, feedback]);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <nav className="flex space-x-4 mb-8">
          <TabButton icon={<BarChart2 />} label="Dashboard" tab="dashboard" activeTab={activeTab} setActiveTab={setActiveTab} />
          <TabButton icon={<AlertCircle />} label="Issues" tab="issues" activeTab={activeTab} setActiveTab={setActiveTab} />
          <TabButton icon={<CheckCircle />} label="Feedback" tab="feedback" activeTab={activeTab} setActiveTab={setActiveTab} />
          <TabButton icon={<Plane />} label="Analytics" tab="analytics" activeTab={activeTab} setActiveTab={setActiveTab} />
        </nav>

        {activeTab === 'dashboard' && <Dashboard issues={issues} feedbackData={feedbackData} />}
        {activeTab === 'issues' && <IssuesList issues={issues} />}
        {activeTab === 'feedback' && <FeedbackForm onSubmit={handleNewFeedback} />}
        {activeTab === 'analytics' && <AnalyticsChart data={feedbackData} />}
      </div>
    </div>
  );
};

interface TabButtonProps {
  icon: React.ReactNode;
  label: string;
  tab: string;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, label, tab, activeTab, setActiveTab }) => (
  <button
    className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
      activeTab === tab ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
    }`}
    onClick={() => setActiveTab(tab)}
  >
    {icon}
    <span>{label}</span>
  </button>
);

export default App;